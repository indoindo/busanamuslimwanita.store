#!/usr/bin/env sh
cd posts
ls -1|head -n 30 | xargs -I {} mv {} ~/storage/shared/1h/ms/content/post
cd ..
hugo --gc --minify