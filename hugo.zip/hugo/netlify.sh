#!/usr/bin/env sh
cd easy
ls -1|head -n 30 | xargs -I {} mv {} /c/hugo/content/recipe
cd ..
hugo --gc --minify
cd public
netlify deploy --prod


#1 taruh file hasil scrapan di folder easy
#2 angka 30 ganti terserah rekom di bawah 100
#3 buat folder dg nama recipe di dalam folder bernama content maka akan jadi /content/recipe
#4 masuk folder lalu hapus isi folder public


#5 ini cara settup netlifynya
#a. stlah berada di folder public, maka bukak foldernya dg cmd/cmder
#b. tekan netlify init
#c. buat project dulu
#d. isikan nama project
#e. 

#6 masuk di folder hugo/content/recipe di dgn cmd/cmde
#7 tkan  bash (sblmnya hrus install dulu aplikasi git agar script bash dpt di baca)
#8 tkan pwd nanti akan muncul alamat directorynya lalu copy
#9 lalu alamat ini ( ~/storage/shared/1h/ms/content/recip ) di ganti menggunakan alamat dr pwd td


#untuk menjalankan filenya buka masuk folder huho dg cmd
#tekan bash (enter)
#bash netlify.sh
