#!/usr/bin/env sh
hugo --gc --minify
cd public
git add .
git commit -m 'deploy'
git push