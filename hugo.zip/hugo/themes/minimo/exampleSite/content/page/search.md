---
title: Search
type: page
layout: search
outputs:
  - html
  - json
---
