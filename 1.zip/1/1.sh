#!/usr/bin/env sh
$es="php shuriken"
"$es"