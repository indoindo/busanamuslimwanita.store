{{ mb_ucwords($post->keyword) }} [Images|Pictures|Pics|Background|PNG|Gif]
