<?php echo e(mb_ucwords($post->keyword)); ?> [Images|Pictures|Pics|Background|PNG|Gif]
<?php /**PATH /storage/emulated/0/1/templates/title/image.blade.php ENDPATH**/ ?>