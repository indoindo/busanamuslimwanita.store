<?php
    $sentences = collect($post->ingredients['sentences']);
    $images = collect($post->ingredients['images']);
?>
<article>
    <p><strong><?php echo e($post->title); ?></strong>. <?php echo e($sentences->take(18)->shuffle()->take(2)->implode(' ')); ?></p>

    <p>
        <?php $image = collect($images)->shuffle()->pop(); ?>
        <?php if($image): ?>
        <figure>
            <img src="<?php echo e($image['image']); ?>" alt="<?php echo e($image['title']); ?>" style="width: 100%; padding: 5px; background-color: grey;"  onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';">
            <figcaption><?php echo e($image['title']); ?> from <?php echo e(parse_url($image['image'], PHP_URL_HOST)); ?></figcaption>
        </figure>
        <?php endif; ?>
        <?php echo e($sentences->shuffle()->take(3)->implode(' ')); ?>

    </p>

    <h3><?php echo e($sentences->shuffle()->pop()); ?></h3>
    <p><?php echo e($sentences->shuffle()->pop()); ?> <?php echo e($sentences->shuffle()->take(6)->implode(' ')); ?></p>
</article>

<section>
<?php $__currentLoopData = collect($images)->shuffle()->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <aside>
        <a href="<?php echo e($image['image']); ?>" target="_blank"><img alt="<?php echo e($image['title']); ?>" src="<?php echo e($image['image']); ?>" width="100%" onerror="this.onerror=null;this.src='<?php echo e($image['thumbnail']); ?>';"></a>
        <small>Source: <?php echo e(parse_url($image['image'], PHP_URL_HOST)); ?></small>
        <p><?php echo e($sentences->shuffle()->pop()); ?></p>
    </aside>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php /**PATH /storage/emulated/0/1/templates/content/image.blade.php ENDPATH**/ ?>