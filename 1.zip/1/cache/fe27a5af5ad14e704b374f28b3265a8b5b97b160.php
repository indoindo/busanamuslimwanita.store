---
title: <?php echo e(trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($post->title))))))); ?>

date: <?php echo e($post->published_at->format('Y-m-d H:i:s')); ?>

publishDate: <?php echo e($post->published_at->format('Y-m-d')); ?>T<?php echo e($post->published_at->format('H:i:s')); ?>Z
description: "<?php echo e(preg_replace('/[^a-zA-Z0-9\s]/', ' ', strip_tags(html_entity_decode(collect($post->ingredients['sentences'])->shuffle()->random())))); ?>"
image: "<?php echo e(collect($post->ingredients['images'])->shuffle()->random()['image']); ?>"
tags: 
- <?php echo e(collect(['trending', 'toyota', 'image'])->random()); ?>

- <?php echo e(preg_replace('/[^a-zA-Z0-9\s]/', ' ', strip_tags(html_entity_decode($post->keyword)))); ?> <?php echo e(collect(['trending', 'news', 'image', 'viral'])->random()); ?>

categories: 
- "<?php echo e($post->category); ?>"

---

<?php echo $post->content; ?><?php /**PATH /sdcard/1/templates/export/hugo/post.blade.php ENDPATH**/ ?>